const database = {
    server: 'localhost',
    user: 'sa',
    password: '3224',
    database: 'dbREVECA',
    "options": {
        "encrypt": false,
        "enableArithAbort": false
    }
};

module.exports = database;
